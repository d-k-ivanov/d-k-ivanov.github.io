#include "MarchingCubesGL.h"

#include <cstdlib>

int main(int argc, char** argv)
{
    MarchingCubesGL::Init(argc, argv);
    return EXIT_SUCCESS;
}
