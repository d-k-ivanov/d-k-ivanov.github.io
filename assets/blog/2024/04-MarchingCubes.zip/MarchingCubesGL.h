#pragma once

#include <GL/glut.h>

#include <cmath>

class MarchingCubesGL
{
    struct GLvector
    {
        GLfloat X;
        GLfloat Y;
        GLfloat Z;
    };

public:
    // Parameters
    inline static GLenum  PolygonMode  = GL_FILL;
    inline static GLint   RowSize      = 16;
    inline static GLfloat StepSize     = 1.0f / static_cast<GLfloat>(RowSize);
    inline static GLfloat SurfaceValue = 1.0f;
    inline static GLfloat Time         = 0.0f;

    // Flags
    inline static bool Spin     = false;
    inline static bool SlowSpin = true;
    inline static bool Move     = false;
    inline static bool SlowMove = true;

    inline static bool Light = true;

    inline static bool ShowSurface = true;

    // Show Points
    inline static bool PointsInternal      = false;
    inline static bool PointsInternalWhite = false;
    inline static bool PointsExtenal       = false;
    inline static bool PointsExtenalWhite  = false;

    // Show Bounding Box
    inline static bool BBoxInternal = false;
    inline static bool BBoxExtenal  = false;

    inline static GLvector SourcePoint[3];

    MarchingCubesGL()  = default;
    ~MarchingCubesGL() = default;

    static GLvoid PrintHelp();
    static GLvoid PrintLog();

    inline static unsigned SampleCount = 11;
    inline static unsigned SampleNum   = 1;
    static GLfloat         Sample1(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample2(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample3(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample4(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample5(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample6(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample7(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample8(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample9(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample10(GLfloat x, GLfloat y, GLfloat z);
    static GLfloat         Sample11(GLfloat x, GLfloat y, GLfloat z);

    inline static GLfloat  (*Sample)(GLfloat x, GLfloat y, GLfloat z) = Sample1;

    static GLvoid MarchCube(GLfloat x, GLfloat y, GLfloat z, GLfloat scale);
    static GLvoid MarchingCubes();

    static GLfloat  GetOffset(GLfloat value1, GLfloat value2, GLfloat surfaceValue);
    static GLvoid   GetColor(GLvector& color, GLvector& position, const GLvector& normal);
    static GLvoid   GetNormal(GLvector& normal, GLfloat x, GLfloat y, GLfloat z);
    static GLvoid   NormalizeVector(GLvector& destination, const GLvector& source);
    static GLvoid   SetTime(GLfloat time);
    static GLvector VertexInterpolation(GLvector p1, GLvector p2, GLfloat value1, GLfloat value2, GLfloat surfaceValue);

    static void Idle();
    static void Init(int argc, char** argv);
    static void DrawScene();
    static void DrawPoint(GLfloat x, GLfloat y, GLfloat z, bool white);
    static void DrawBoundingBox(GLfloat x, GLfloat y, GLfloat z, GLfloat scale);
    static void Resize(GLsizei width, GLsizei height);
    static void Keyboard(unsigned char key, int x, int y);
    static void Special(int key, int x, int y);
};
