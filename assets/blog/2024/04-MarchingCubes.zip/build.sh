cmake -B build -G "Ninja Multi-Config" -S .
cmake --build build --config Release
